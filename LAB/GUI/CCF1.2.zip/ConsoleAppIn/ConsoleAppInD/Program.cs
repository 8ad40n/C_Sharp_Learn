﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppInD
{
    class Program
    {
        static void Main(string[] args)
        {
            //Person[] people = new Person[3];
            //people[0] = new Employee("Bruce", new AddressFormat(32, 87, 1290, "Sylhet"), "O+", 10000);
            //people[1] = new Student("Clerk", new AddressFormat(24, 19, 1300, "Khulna"), "AB+", 3.29);
            //people[2] = new Employee("Diana", new AddressFormat(61, 55, 2387, "Bogura"), "B+", 19800);

            //foreach (Person p in people)
            //{
            //    p.ShowInfo();
            //    Console.WriteLine();
            //}

            //XYZOrganization t = new XYZOrganization();
            //XYZOrganization.AddPerson(new Employee("Bruce", new AddressFormat(32, 87, 1290, "Sylhet"), "O+", 10000));
            //XYZOrganization.AddPerson(new Student("Clerk", new AddressFormat(24, 19, 1300, "Khulna"), "AB+", 3.29));
            //XYZOrganization.AddPerson(new Employee("Diana", new AddressFormat(61, 55, 2387, "Bogura"), "B+", 19800));
            //XYZOrganization.AddPerson(new Student("Arthur", new AddressFormat(49, 71, 7690, "Nouga"), "AB+", 3.62));
            //XYZOrganization.ShowAll();
            //XYZOrganization.Search("P-2-S");
            //XYZOrganization.DeletePerson("P-4-S");

            //Console.WriteLine("End");
            //Console.ReadLine();
        }
    }
}
