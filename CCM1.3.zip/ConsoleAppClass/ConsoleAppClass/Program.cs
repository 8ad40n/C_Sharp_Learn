﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppClass
{
    class Program
    {
        static void Main(string[] args)
        {
            //AddressFormat a1 = new AddressFormat(4, 2, 7566, "Khulna");

            //Student s1 = new Student();
            //s1.Id = 100; //s1.SetId(100); //s1.id = 100;
            //s1.Name = "Bruce"; //s1.SetName("Bruce"); //s1.name = "Bruce";
            //s1.Cgpa = 4.26; //s1.SetCgpa(4.26); //s1.cgpa = 3.26;
            //s1.BloodGroup = "B+"; //s1.SetBloodGroup("B+"); //s1.bloodGroup = "B+";
            //s1.Address = new AddressFormat(4, 2, 7566, "Khulna"); //s1.SetAddress(new AddressFormat(4, 2, 7566, "Khulna"));
            //s1.PrintStudentInfo();

            //Student s = s1;
            //s.id = 200;
            //Console.WriteLine("{0},{1}", s.Id, s.GetId(), s1.id);

            //Student s2 = new Student(200, "Clerk", -3.11, "O+", new AddressFormat(34, 82, 1699, "Sylhet"));
            //s2.PrintStudentInfo();

            //int[] ax = new int[5] { 4, 2, 7, 9, 1 };
            //for (byte p = 0; p < ax.Length; p++)
            //{
            //    Console.Write("{0} ", ax[p]);
            //}
            //Console.WriteLine();

            //byte q = 0;
            //while (q < 5)
            //{
            //    Console.Write("{0} ", ax[q]);
            //    q++;
            //}
            //Console.WriteLine();

            //q = 6;
            //do
            //{
            //    Console.Write("{0} ", q);
            //    q++;
            //}
            //while (q < 5);
            //Console.WriteLine();

            //foreach (int w in ax)
            //{
            //    Console.Write("{0} ", w);
            //}
            //Console.WriteLine();

            //int[,] bx = new int[4, 3] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 }, { 10, 11, 12 } };

            //byte r = 0, c;
            //while (r < 4)
            //{
            //    c = 0;
            //    while (c < 3)
            //    {
            //        Console.Write("{0} ", bx[r, c]);
            //        c++;
            //    }
            //    Console.WriteLine();
            //    r++;
            //}

            //foreach (int w in bx)
            //{
            //    Console.Write("{0} ", w);
            //}
            //Console.WriteLine();

            //int[,,,] z = new int[3, 2, 4, 2];

            //int[][] jx = new int[4][];
            //jx[0] = new int[3] { 1, 2, 3 };
            //jx[1] = new int[2] { 4, 5 };
            //jx[2] = new int[5] { 6, 7, 8, 9, 10 };
            //jx[3] = new int[1] { 11 };

            //byte r = 0, c;
            //while (r < jx.Length)
            //{
            //    c = 0;
            //    while (c < jx[r].Length)
            //    {
            //        Console.Write("{0} ", jx[r][c]);
            //        c++;
            //    }
            //    Console.WriteLine();
            //    r++;
            //}
            //Test t = new Test();
            //int g = Test.b;
            //g = t.c;
        }
    }
}

