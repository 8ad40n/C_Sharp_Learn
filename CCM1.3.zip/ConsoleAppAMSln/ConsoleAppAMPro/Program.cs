﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAMPro
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            School ss = new School();
            
            //ConsoleAppAMPro.Sub.College cs = new Sub.College();
            //System.Console.WriteLine();
        }
    }
}
