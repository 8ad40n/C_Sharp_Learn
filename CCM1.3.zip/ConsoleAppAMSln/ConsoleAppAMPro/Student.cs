﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAMPro
{
    public class Student
    {
        public int a;
        private int b;
        protected int c;
        internal int d;
        protected internal int e;
        private protected int f;

        void M1()
        { 
        }
    }
}
