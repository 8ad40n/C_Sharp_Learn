﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAMPro.Sub
{
    class College : Student
    {
        public int m;
        private int n;
        protected int o;
        internal int p;
        protected internal int q;

        void M2()
        {
            this.
        }
    }
}
